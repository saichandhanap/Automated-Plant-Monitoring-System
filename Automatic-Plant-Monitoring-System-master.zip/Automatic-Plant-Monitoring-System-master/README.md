# Automatic-Plant-Monitoring-System
An IoT application made using Arduino and Raspberry Pi for monitoring a plan. Also consists of manual control of motors through the website created using Django,HTML,CSS and Javascript.
